# Pursuit-Core-iOS-To-Do-List
To do list app uses FileManager to persists items to the documents directory
